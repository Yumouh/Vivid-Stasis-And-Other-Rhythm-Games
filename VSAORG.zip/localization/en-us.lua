return {
    descriptions = {
        Mod={
            Vsaorg={
                name = "VividStasisAndOtherRhythmGames",
                text = {
                    "Adds {C:red}30{} vanilla-style Jokers based on {C:purple}Vivid{}{C:dark_edition}/{}{C:spectral}Stasis{} and many MUG songs",
                    " ",
                    "{C:edition}Concept{}",
                    "Yumouk",
                    " ",
                    "{C:gold}Code{}",
                    "Deepseek(yes it's true)",
                    " ",
                    "{C:blue}Art{}",
                    "Fyato(femboy)",
                    " ",
                    "{C:green}Thanks to{}",
                    "Baimao, Brookling,",
                    "Youlingosk and 280chan",
                    " ",
                    "Click to view the {C:blue}wiki{} page：",
                    "{C:attention}https://balatromods.miraheze.org/wiki/VividStasisAndOtherRhythmGames{}",
                    " ",
                    "Also try {C:attention}Brook{},also an excellent vanilla mod made by Brookling&Baimao",
                    "{C:attention}https://balatromods.miraheze.org/Brook{}"
                }
            }
        },
    },
}